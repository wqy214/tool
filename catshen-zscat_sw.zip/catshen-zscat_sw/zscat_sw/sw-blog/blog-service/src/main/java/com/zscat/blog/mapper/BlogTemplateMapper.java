package com.zscat.blog.mapper;


import com.zsCat.common.base.MyMapper;
import com.zscat.blog.api.model.BlogTemplate;

public interface BlogTemplateMapper extends MyMapper<BlogTemplate> {
}