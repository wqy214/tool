import com.github.pagehelper.PageInfo;


import com.zscat.CmsServiceApplication;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = CmsServiceApplication.class)
public class Test {
    @Autowired
    private WebApplicationContext webApplicationContext;





    @org.junit.Test
    public void testO(){

    }





}
