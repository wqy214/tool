import com.alibaba.fastjson.JSONObject;


import javax.annotation.Resource;
import java.util.*;

/**
 * @author jd.wang
 * @date 2017-04-11
 */
public class AuthControllerTest extends MockMvcBase {


}
