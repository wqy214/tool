package com.zscat.cms.mapper;

import com.zsCat.common.base.MyMapper;
import com.zscat.cms.model.CmsComment;

public interface CmsCommentMapper extends MyMapper<CmsComment> {
}