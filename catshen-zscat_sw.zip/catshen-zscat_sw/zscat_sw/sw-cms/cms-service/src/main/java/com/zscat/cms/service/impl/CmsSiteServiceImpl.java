 /*
  * Powered By zsCat, Since 2014 - 2020
  */
package com.zscat.cms.service.impl;

import com.zsCat.common.base.ServiceMybatis;
import com.zscat.cms.service.CmsSiteService;

import com.zscat.cms.model.CmsSite;

 /**
 * 
 * @author zsCat 2017-4-14 13:56:18
 * @Email: 951449465@qq.com
 * @version 4.0v
 */
 @com.alibaba.dubbo.config.annotation.Service(version = "1.0.0",retries = 0,timeout = 60000)
public class CmsSiteServiceImpl extends ServiceMybatis<CmsSite> implements CmsSiteService {

 
    
}
