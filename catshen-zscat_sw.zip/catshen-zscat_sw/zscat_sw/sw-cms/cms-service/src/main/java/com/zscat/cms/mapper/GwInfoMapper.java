package com.zscat.cms.mapper;

import com.zsCat.common.base.MyMapper;
import com.zscat.cms.model.GwInfo;

public interface GwInfoMapper extends MyMapper<GwInfo> {
}