 /*
  * Powered By zsCat, Since 2014 - 2020
  */
package com.zscat.cms.service.impl;

 import com.alibaba.dubbo.config.annotation.Service;
 import com.zsCat.common.base.ServiceMybatis;
 import com.zscat.cms.model.CmsArticle;
 import com.zscat.cms.model.GwNav;
 import com.zscat.cms.service.CmsArticleService;
 import com.zscat.cms.service.GwNavService;

 /**
 * 
 * @author zsCat 2017-4-14 13:56:18
 * @Email: 951449465@qq.com
 * @version 4.0v
 */
 @Service(version = "1.0.0",retries = 0,timeout = 60000)
public class GwNavServiceImpl extends ServiceMybatis<GwNav> implements GwNavService {

 

    
}
