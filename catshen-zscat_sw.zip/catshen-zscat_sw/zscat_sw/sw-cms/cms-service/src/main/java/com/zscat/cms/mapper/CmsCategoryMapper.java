package com.zscat.cms.mapper;

import com.zsCat.common.base.MyMapper;
import com.zscat.cms.model.CmsCategory;

public interface CmsCategoryMapper extends MyMapper<CmsCategory> {
}