package com.zscat.cms.mapper;

import com.zsCat.common.base.MyMapper;
import com.zscat.cms.model.CmsLink;

public interface CmsLinkMapper extends MyMapper<CmsLink> {
}