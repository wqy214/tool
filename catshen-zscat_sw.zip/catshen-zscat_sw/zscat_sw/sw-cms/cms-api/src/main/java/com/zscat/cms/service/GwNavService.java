 /*
  * Powered By zsCat, Since 2014 - 2020
  */
package com.zscat.cms.service;


import com.zsCat.common.base.BaseService;
import com.zscat.cms.model.CmsArticle;
import com.zscat.cms.model.GwNav;

 /**
  *
  * @author zsCat 2017-4-14 13:56:18
  * @Email: 951449465@qq.com
  * @version 4.0v
  */
 public interface GwNavService extends BaseService<GwNav> {


 }
