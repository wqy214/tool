 /*
  * Powered By zsCat, Since 2014 - 2020
  */
package com.zscat.cms.service;


import com.zsCat.common.base.BaseService;
import com.zscat.cms.model.CmsArticle;

/**
 * 
 * @author zsCat 2017-4-14 13:56:18
 * @Email: 951449465@qq.com
 * @version 4.0v
 */
public interface CmsArticleService extends BaseService<CmsArticle> {


}
