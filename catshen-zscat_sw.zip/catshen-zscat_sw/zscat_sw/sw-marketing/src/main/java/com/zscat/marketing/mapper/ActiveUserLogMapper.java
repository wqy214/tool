package com.zscat.marketing.mapper;

import com.zscat.base.MyMapper;
import com.zscat.marketing.model.ActiveUserLog;

public interface ActiveUserLogMapper extends MyMapper<ActiveUserLog> {
}