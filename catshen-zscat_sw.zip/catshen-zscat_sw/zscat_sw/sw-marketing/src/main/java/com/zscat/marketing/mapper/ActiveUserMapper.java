package com.zscat.marketing.mapper;

import com.zscat.base.MyMapper;
import com.zscat.marketing.model.ActiveUser;

public interface ActiveUserMapper extends MyMapper<ActiveUser> {
}