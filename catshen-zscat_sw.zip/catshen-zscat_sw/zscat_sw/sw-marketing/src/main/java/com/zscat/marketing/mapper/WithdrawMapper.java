package com.zscat.marketing.mapper;

import com.zscat.base.MyMapper;
import com.zscat.marketing.model.Withdraw;

public interface WithdrawMapper extends MyMapper<Withdraw> {
}