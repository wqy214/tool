微信公众号 营销系统
[测试微信号](https://mp.weixin.qq.com/debug/cgi-bin/sandboxinfo?action=showinfo&t=sandbox/index)
![输入图片说明](https://git.oschina.net/uploads/images/2017/0901/155122_8ddf87dc_134431.png "weixin1.png")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0901/155136_4ead3164_134431.png "weixin2.png")
### 点击推广计划的 推广后台

![输入图片说明](https://git.oschina.net/uploads/images/2017/0901/155504_270448c7_134431.jpeg "w4.jpg")
![输入图片说明](https://git.oschina.net/uploads/images/2017/0901/155516_5c49b59a_134431.jpeg "w3.jpg")